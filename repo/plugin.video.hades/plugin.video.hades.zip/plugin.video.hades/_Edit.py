import xbmcaddon

MainBase = 'http://casmart.comxa.com/Addon/home.xml'
addon = xbmcaddon.Addon('plugin.video.hades')